// Empty placeholder for HTML checks
