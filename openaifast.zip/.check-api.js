// Empty placeholder for API checks
