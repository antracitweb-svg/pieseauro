const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const js=fs.readFileSync('script.js','utf8');
// ids referenced in JS via $('#...')
const refs=new Set();
const rre=/\$\(\s*'#([A-Za-z][\w-]*)'/g; let m;
while((m=rre.exec(js))) refs.add(m[1]);
// ids defined in html
const htmlIds=new Set();
const ire=/id\s*=\s*"([^"]+)"/g;
while((m=ire.exec(html))) htmlIds.add(m[1]);
// ids defined dynamically in JS templates (id="...")
const jsIds=new Set();
const jre=/id\s*=\s*"([^"]+)"/g;
while((m=jre.exec(js))) jsIds.add(m[1]);
const missing=[...refs].filter(id=>!htmlIds.has(id)&&!jsIds.has(id)).sort();
console.log('--- ID-uri folosite in script.js dar negasite nicieri ---');
if(missing.length) missing.forEach(x=>console.log(' ',x)); else console.log('  (toate exista)');
// css braces balance
const css=fs.readFileSync('style.css','utf8');
const open=(css.match(/\{/g)||[]).length, close=(css.match(/\}/g)||[]).length;
console.log('--- style.css ---');
console.log('  acolade: {',open,'}',close, open===close?'OK':'DEZECILIBRU');
